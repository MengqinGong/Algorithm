import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private byte[] status;
    private WeightedQuickUnionUF sites;
    private int size;

    public Percolation(int n) {
        if (n <= 0) throw new IllegalArgumentException("n should be positive integer");
        status = new byte[n * n];
        for (int i = 0; i < n * n; i++) status[i] = 0;
        sites = new WeightedQuickUnionUF(n * n);
        size = n;
    }

    private int xyTo1D(int x, int y) {
        return (x - 1) * size + y - 1;
    }

    private void validate(int i, int j) {
        if (i <= 0 || i > size || j <= 0 || j > size) throw new IndexOutOfBoundsException("index " +
                i + " or " + j + " is not between 1 and " + size);
    }

    public void open(int i, int j) {
        validate(i, j);
        int index = xyTo1D(i, j);
        if (!isOpen(i, j)) {
            status[index] = 1;
            if (i >= 2 && isOpen(i - 1, j)) sites.union(xyTo1D(i - 1, j), index);
            if (i < size && isOpen(i + 1, j)) sites.union(xyTo1D(i + 1, j), index);
            if (j >= 2 && isOpen(i, j - 1)) sites.union(xyTo1D(i, j - 1), index);
            if (j < size && isOpen(i, j + 1)) sites.union(xyTo1D(i, j + 1), index);
        }
    }

    public boolean isOpen(int i, int j) {
        validate(i, j);
        return status[xyTo1D(i, j)] == 1;
    }

    public boolean isFull(int i, int j) {
        validate(i, j);

        if (!isOpen(i, j)) {
            return false;
        }

        int componentIdentifier = sites.find(xyTo1D(i, j));

        for (int j1 = 1; j1 <= size; j1++) {
            if (isOpen(1, j1) && sites.connected(componentIdentifier, xyTo1D(1, j1))) return true;
        }

        return false;
    }

    public boolean percolates() {
        for (int j = 1; j <= size; j++) {
            if (isFull(size, j)) return true;
        }
        return false;
    }

    public static void main(String[] args) {
        // test client (optional)
        new Percolation(2);
    }
}
